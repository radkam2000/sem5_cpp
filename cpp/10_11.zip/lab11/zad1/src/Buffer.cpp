#include "Buffer.h"
#include <iostream>

Buffer::Buffer(){
    std::cout<<"Konstruktor Buffer"<<std::endl;
}

Buffer::~Buffer(){
    std::cout<<"Destruktor Buffer"<<std::endl;
}