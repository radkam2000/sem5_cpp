#include "class1.h"

Class1::Class1()
{

}
