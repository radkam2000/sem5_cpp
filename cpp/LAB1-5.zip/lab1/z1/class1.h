#ifndef CLASS1_H
#define CLASS1_H


class Class1
{
public:
    Class1();
};

#endif // CLASS1_H
