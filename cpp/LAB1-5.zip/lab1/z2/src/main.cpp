#include "Animal.h"
#include "Dog.h"

int main(){
    Dog pies("rasa",4,4,"nazwa psa",4,1);
    pies.info();
    std::cout<<"-----"<<std::endl;
    return 0;
}